﻿using System;
using System.Collections.Generic;

namespace OOPAlapok
{
    public class Szemely
    {
        protected string _nev;
        protected int _kor;

        public Szemely(string nev, int kor)
        {
            _nev = nev;
            _kor = kor;

        }

        public string Nev
        {
            get { return _nev; }
        }

        public int Kor
        {
            get { return _kor; }
            set
            {
                if (value >= 0)
                    _kor = value;
                else
                    Console.WriteLine("Hibás érték.");

            }
        }

        public override string ToString()
        {
            return $"A tanuló neve {_nev} életkora {_kor}";
        }

    }

    class bankszamla
    {
        private int _egyenleg;

        public int egyenleg
        {
            set
            {
                if (value >= 0)
                {
                    _egyenleg = value;
                }
                else
                {
                    Console.WriteLine("az egyenleg nem lehet kisebb mint 0");
                }
            }

        }

        private void betesz()
        {

        }

        private void kivesz()
        {


        }

        class hallgato : Szemely
        {
            private string _neptunkod;

            public string Neptunkod
            {
                get { return _neptunkod; }
                set { if(value.Length <= 6)
                    _neptunkod = value; }
            }

            public hallgato(string nev, int kor) : base(nev, kor)
            {
                {

                  

                }
            }

        }
        class dolgozo : Szemely
        {
            private string _munkakor;
            public string Munkakor
            {
                get { return _munkakor; }
                set { _munkakor = value; }
            }
            public dolgozo(string nev, int kor) : base(nev, kor)
            {
            }
        }
        internal class Program
        {
            static void Main(string[] args)
            {
                Szemely tanulo1 = new Szemely("Kiss Ilona", 34);

                Console.WriteLine(tanulo1);

                List<hallgato> hallgatolista = new List<hallgato>();

                for(int i = 0; i < 2; i++)
                {
                    Console.Write($"Kérem {i + 1} nevet");
                    string nev = Console.ReadLine();
                    Console.Write($"Kérem {i + 1} eletkorat");
                    int kor = int.Parse(Console.ReadLine());
                    hallgato tanulo = new hallgato(nev, kor);
                    Console.Write($"Kérem {i + 1} neptunkodot");
                    string neptunkod = Console.ReadLine();
                    tanulo.Neptunkod = neptunkod;
                    hallgatolista.Add( tanulo );

                }
                foreach ( var item in hallgatolista)
                {
                    Console.WriteLine($"{item.Nev} { item.Kor} {item.Neptunkod}");
                }
            }
        }
    }
}
